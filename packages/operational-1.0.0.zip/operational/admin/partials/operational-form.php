<?php
/**
 * Admin form template for Operational plugin
 *
 * @package    Operational
 * @subpackage Operational/admin/partials
 */

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
    die;
}
?>

<div class="wrap">

    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>

    <strong>
        This plugin requires a Operational API key. Get yours from operational.co
        <br />
        After getting the key, enter it in the form below and set 'Log User Activity' to Yes.
    </strong>
    
    <form method="post" action="options.php">
        <?php 
            // Add nonce field
            wp_nonce_field('operational_settings_nonce', 'operational_nonce');
            
            settings_fields('operational_options');
            do_settings_sections('operational_options');
        ?>
        
        
        <?php submit_button('Save Settings'); ?>
    </form>
</div> 